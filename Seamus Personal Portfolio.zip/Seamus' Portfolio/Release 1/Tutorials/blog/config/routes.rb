Rails.application.routes.draw do

  resources :articles
  article GET    /articles/:id(.:format)      articles#show
  articles GET   /articles(.:format)          articles#index

  root 'welcome#index'
end