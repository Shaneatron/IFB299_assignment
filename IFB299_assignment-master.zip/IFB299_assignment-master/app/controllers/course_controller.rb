class CourseController < ApplicationController
  def info
  end
end
