class CentreController < ApplicationController
  def info
  end
end
