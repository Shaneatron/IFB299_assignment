class RegisterController < ApplicationController
  def now
  end
end
