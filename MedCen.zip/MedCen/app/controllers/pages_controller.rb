class PagesController < ApplicationController
  def show
  end
end
