class AccountController < ApplicationController
  def index
  end
end
